#using BilevelJuMP, HiGHS

using JuMP, Ipopt

function solve_lower_level(x...)
    model = Model(Ipopt.Optimizer)
    set_silent(model)
    @variable(model, y[1:2])
    @objective(
        model,
        Max,
        x[1]* y[1] +x[2]*y[2],
    )
    @constraint(model, (y[1] - 10)^2 + (y[2] - 10)^2 <= 25)
    optimize!(model)
    #@assert is_solved_and_feasible(model)
    return objective_value(model), value.(y)
end

function V(x...)
    f, _ = solve_lower_level(x...)
    return f
end
#print(V(3,4))

model = Model(Ipopt.Optimizer)
@variable(model, x[1:2] >= 0)
@expression(model, exp_V, V)
#@constraint(model, x[1:2] .<= 100)
@objective(model, Min, x[1] + x[2] + exp_V(x[1], x[2]))
optimize!(model)
#@assert is_solved_and_feasible(model)
solution_summary(model)

