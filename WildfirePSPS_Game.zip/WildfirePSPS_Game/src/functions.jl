function greet_WildfirePSPS_Game()
    return "Hello WildfirePSPS_Game!"
end

using JuMP, HiGHS
function lp_solve()
    # Preparing an optimization model
    m = Model(HiGHS.Optimizer)
    n_gens = 1
    n_demands = 1
    n_lines = 1
    n_nodes = 2
    p_min = 0*[1:n_gens]
    p_max = [100,100]
    d_nom = [50,150]
    d = [50,150]
    d_min = 0*[1:n_demands]
    max_line_flow = 100 #u
    u = max_line_flow
    # Declaring variables
    # Generators    
    @variable(m, p[i=1:n_nodes]>= 0)
    # Demands
    #@variable(m, d[i=1:n_nodes]>=0)
    # Line Flows   
    @variable(m, f[i=1:n_nodes,j=1:n_nodes])
    # Line Reactances
    #@variable(m, x[i=1:n_lines])
    # Nodal Phase Angles
    #@variable(m, theta[i=1:n_nodes])

    # Adding constraints
    # Phase and Voltage Balance
    #@constraint(m, x*f - theta + theta = 0)
    # Generator Limits
    @constraint(m, c_p[i=1:n_nodes], p[i] <= p_max[i])
    # Demand Limits
    @constraint(m, c_d[i=1:n_nodes], d[i] <= d_nom[i])
    # Line Flow Limits
    @constraint(m, c_lf1[i=1:n_nodes,j=1:n_nodes], f[i,j] -f[j,i] <= u)
    @constraint(m, c_lf2[i=1:n_nodes, j=1:n_nodes], -u <= f[i,j] -f[j,i])
    # Network Power Balance
    @constraint(m, c_pb[1], sum(p[i] for i in 1:n_nodes) == sum(d[i] for i in 1:n_nodes))
    # Line Flow Constraint
    @constraint(m, c_lfc[i=1:n_nodes], sum(f[i,j] for j in 1:n_nodes) - sum(f[j,i] for j in 1:n_nodes) == p[i] - d[i])
    @constraint(m, c_lfc2[i=1:n_nodes], f[i,i]  <= p[i])
    
    
    # Setting the objective
    @objective(m, Max, sum(p[i] for i in 1:n_nodes))

  

    # Printing the prepared optimization model
    print(m)

    # Solving the optimization problem
    JuMP.optimize!(m)

    # Printing the optimal solutions obtained
    println("Optimal Solutions:")
    println("p = ", JuMP.value.(p))
    println("d = ", JuMP.value.(d))
    println("f = ", JuMP.value.(f))

    return 
end