using WildfirePSPS_Game
using Test

@testset "WildfirePSPS_Game.jl" begin
    # Write your tests here.
end
